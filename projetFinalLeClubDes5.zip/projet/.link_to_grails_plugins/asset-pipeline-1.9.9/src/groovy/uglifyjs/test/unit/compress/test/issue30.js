var a = 1 << 3;
var b = 8 >> 1;
var c = 8 >>> 1;