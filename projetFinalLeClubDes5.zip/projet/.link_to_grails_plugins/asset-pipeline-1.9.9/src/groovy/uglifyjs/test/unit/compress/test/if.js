var a = 1;
if (a == 1) {
	a = 2;
} else {
	a = 17;
}
