package projet



import static org.springframework.http.HttpStatus.*
import grails.transaction.Transactional

@Transactional(readOnly = true)
class UtilisateurController {

	static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]


	def index() {
	}

	def logout() {
		session.user=null;
		redirect(uri: "")

		
	}
	
	
	def login() {

		
		 
		session.user=Utilisateur.findByIdentifiant(params.identifiant);
		if(session.user!=null) {
			if(session.user?.mdp==params.mdp) {
				if(session.user?.droit)
				{
					redirect(uri: "/sondage/")
				}
				else{
					redirect(uri: "/sondage/")
				}
				
			}
			else{
				session.user=null;
				redirect(uri:"/utilisateur/mauvaisMotDePasse")
			}
		}

		else {
			session.user=null;
			redirect(uri:"/utilisateur/mauvaisMotDePasse")
		}
	}
	
	def mauvaisMotDePasse()
	{
		
	}
	
	

	def show(Utilisateur utilisateurInstance) {
		respond utilisateurInstance
	}

	def create() {
		if(session.user==null)
		{
			redirect(uri: "")
		}
		respond new Utilisateur(params)
	}

	@Transactional
	def save(Utilisateur utilisateurInstance) {
		if (utilisateurInstance == null) {
			notFound()
			return
		}

		if (utilisateurInstance.hasErrors()) {
			respond utilisateurInstance.errors, view:'create'
			return
		}
		
		
		utilisateurInstance.identifiant=utilisateurInstance.prenom+"."+utilisateurInstance.nom
		utilisateurInstance.mdp=utilisateurInstance.nom
		utilisateurInstance.save flush:true

		redirect(uri: "")
	}

	def edit(Utilisateur utilisateurInstance) {
		if(session.user==null)
		{
			redirect(uri: "")
		}
		if(!session.user.droit)
		{
			redirect(uri: "")
		}
		respond utilisateurInstance
	}

	@Transactional
	def update(Utilisateur utilisateurInstance) {
		//changer de mot passe
		if (utilisateurInstance == null) {
			notFound()
			return
		}

		if (utilisateurInstance.hasErrors()) {
			respond utilisateurInstance.errors, view:'edit'
			return
		}
		utilisateurInstance.mdp=params.password;
		utilisateurInstance.save flush:true

		request.withFormat {
			form multipartForm {
				flash.message = message(code: 'default.updated.message', args: [
					message(code: 'Utilisateur.label', default: 'Utilisateur'),
					utilisateurInstance.id
				])
				redirect(uri: "/sondage/")
			}
			'*'{ respond utilisateurInstance, [status: OK] }
		}
	}

	@Transactional
	def delete(Utilisateur utilisateurInstance) {

		if (utilisateurInstance == null) {
			notFound()
			return
		}

		utilisateurInstance.delete flush:true

		request.withFormat {
			form multipartForm {
				flash.message = message(code: 'default.deleted.message', args: [
					message(code: 'Utilisateur.label', default: 'Utilisateur'),
					utilisateurInstance.id
				])
				redirect action:"index", method:"GET"
			}
			'*'{ render status: NO_CONTENT }
		}
	}

	protected void notFound() {
		request.withFormat {
			form multipartForm {
				flash.message = message(code: 'default.not.found.message', args: [
					message(code: 'utilisateur.label', default: 'Utilisateur'),
					params.id
				])
				redirect action: "index", method: "GET"
			}
			'*'{ render status: NOT_FOUND }
		}
	}
}
