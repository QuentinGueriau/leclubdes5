package projet



import static org.springframework.http.HttpStatus.*
import grails.converters.JSON
import grails.transaction.Transactional

@Transactional(readOnly = true)
class SondageController {

    static allowedMethods = [save: "POST", update: "PUT", delete: "DELETE"]

	
	def answer(Sondage sondageInstance) {
		if(session.user==null)
		{
			redirect(uri: "")
		}
		if(session.user.droit)
		{
			redirect(uri: "")
		}
		respond sondageInstance
    }
	
	def suppr(Sondage sondageInstance) {
		if(sondageInstance==null)
		{
			redirect(uri: "")
		}
		
		sondageInstance.delete(flush: true)
		redirect(uri: "")
	}
	
	def saveAnswer() {
		
		def sondageInstance = Sondage.findById(params.idSondage);
		println sondageInstance.enseignement.nom
		if (sondageInstance == null) {
			notFound()
			return
		}

		sondageInstance.save();
		
		def reponse = new Reponse(note: params.note);
		println reponse.note
		
		sondageInstance.addToReponses reponse;
		sondageInstance.save();
		println reponse.sondage.id
		reponse.save();
		redirect(uri: "")
		def user=new Utilisateur();
		user=Utilisateur.findById(session.user.id)
		def ens=sondageInstance.enseignement
		projet.Emargement.findAll("from Emargement as e where e.enseignement=?", [ens]).each {emar ->
				if(emar.utilisateur.id==user.id)
				{
					user.save();
					ens.save()
					println "hey"
					println emar.id
					user.removeFromEmargement emar
					ens.removeFromEmargement emar;
					emar.delete(flush: true);
					user.save();
					ens.save()
					println "1hey1"
					def emarg = new Emargement(aRepondu: true);
					user.addToEmargement emarg
					ens.addToEmargement emarg;
					user.save(flush: true);
					ens.save()
				
				}
			
			
		}
		
		
		
		
	}
	
	
	
	
	
	
    def index(Integer max) {
		if(session.user==null)
		{
			redirect(uri: "")
		}
		
		 [reponseInstanceList: Reponse.list(params), sondageInstanceList: Sondage.list(params), emargementInstanceList: Emargement.list(params)]
    }

	
	
	
    def show(Sondage sondageInstance) {
		if(session.user==null)
		{
			redirect(uri: "")
		}
		respond sondageInstance
    }

    def create(Enseignement enseignementInstance) {
		if(session.user==null)
		{
			redirect(uri: "")
		}
		if(!session.user.droit)
		{
			redirect(uri: "")
		}
        [sondageInstance: new Sondage(params),enseignementInstance: enseignementInstance]
    }

   @Transactional
	def save(Sondage sondageInstance) {
		if(params.dateFin_year>params.dateDebut_year) {
			if (sondageInstance == null) {
				notFound()
				return
			}

			def sondage = new Sondage(dateDebut: params.dateDebut, dateFin: params.dateFin);

			def enseignementInstance=Enseignement.findById(params.idEnseignement);

			enseignementInstance.addToSondage sondage;
			enseignementInstance.save()

			redirect(uri: "")
		}
		else if(params.dateFin_year==params.dateDebut_year) {
			if(params.dateFin_month>params.dateDebut_month) {
				if (sondageInstance == null) {
					notFound()
					return
				}

				def sondage = new Sondage(dateDebut: params.dateDebut, dateFin: params.dateFin);

				def enseignementInstance=Enseignement.findById(params.idEnseignement);

				enseignementInstance.addToSondage sondage;
				enseignementInstance.save()

				redirect(uri: "")
			}
			else if(params.dateFin_month==params.dateDebut_month) {
				if(params.dateFin_day>params.dateDebut_day) {
					if (sondageInstance == null) {
						notFound()
						return
					}

					def sondage = new Sondage(dateDebut: params.dateDebut, dateFin: params.dateFin);

					def enseignementInstance=Enseignement.findById(params.idEnseignement);

					enseignementInstance.addToSondage sondage;
					enseignementInstance.save()

					redirect(uri: "")
				}
				else
			redirect(uri:"/sondage/mauvaiseDate")
			}
			else
			redirect(uri:"/sondage/mauvaiseDate")
		}
		else
			redirect(uri:"/sondage/mauvaiseDate")
	}
	
	
	
	def mauvaiseDate() {
	}
	def mauvaiseDate1() {
	}

    def edit(Sondage sondageInstance) {
        respond sondageInstance
    }

   @Transactional
	def update(Sondage sondageInstance) {
		
		if(params.dateDebut.after(params.dateFin))
		{
			redirect(uri:"/sondage/mauvaiseDate1")
			return
		}
		else
		{
		if(params.dateFin_year>params.dateDebut_year) {
			if (sondageInstance == null) {
				notFound()
				return
			}

			if (sondageInstance.hasErrors()) {
				respond sondageInstance.errors, view:'edit'
				return
			}

			sondageInstance.save flush:true

			request.withFormat {
				form multipartForm {
					flash.message = message(code: 'default.updated.message', args: [
						message(code: 'Sondage.label', default: 'Sondage'),
						sondageInstance.id
					])
					redirect(action:'index')
				}
				'*'{
					respond sondageInstance, [status: OK]
				}
			}
		}
		else if(params.dateFin_year==params.dateDebut_year) {
			if(params.dateFin_month>params.dateDebut_month) {
				if (sondageInstance == null) {
					notFound()
					return
				}

				if (sondageInstance.hasErrors()) {
					respond sondageInstance.errors, view:'edit'
					return
				}

				sondageInstance.save flush:true

				request.withFormat {
					form multipartForm {
						flash.message = message(code: 'default.updated.message', args: [
							message(code: 'Sondage.label', default: 'Sondage'),
							sondageInstance.id
						])
						redirect(action:'index')
					}
					'*'{
						respond sondageInstance, [status: OK]
					}
				}
			}
			else if(params.dateFin_month==params.dateDebut_month) {
				if(params.dateFin_day>params.dateDebut_day) {
					if (sondageInstance == null) {
						notFound()
						return
					}

					if (sondageInstance.hasErrors()) {
						respond sondageInstance.errors, view:'edit'
						return
					}

					sondageInstance.save flush:true

					request.withFormat {
						form multipartForm {
							flash.message = message(code: 'default.updated.message', args: [
								message(code: 'Sondage.label', default: 'Sondage'),
								sondageInstance.id
							])
							redirect(action:'index')
						}
						'*'{
							respond sondageInstance, [status: OK]
						}
					}
				}
				else
				redirect(uri:"/sondage/mauvaiseDate")
			}
			else
				redirect(uri:"/sondage/mauvaiseDate1")
		}
		else
				redirect(uri:"/sondage/mauvaiseDate1")
	}
   }
    @Transactional
    def delete(Sondage sondageInstance) {
		if(session.user==null)
		{
			redirect(uri: "")
		}
        else
		{
			if (sondageInstance == null) {
	            notFound()
	            return
	        }
	
	        sondageInstance.delete flush:true
	
	        request.withFormat {
	            form multipartForm {
	                flash.message = message(code: 'default.deleted.message', args: [message(code: 'Sondage.label', default: 'Sondage'), sondageInstance.id])
	                redirect action:"index", method:"GET"
	            }
	            '*'{ render status: NO_CONTENT }
	        }
		}
    }

    protected void notFound() {
        request.withFormat {
            form multipartForm {
                flash.message = message(code: 'default.not.found.message', args: [message(code: 'sondage.label', default: 'Sondage'), params.id])
                redirect action: "index", method: "GET"
            }
            '*'{ render status: NOT_FOUND }
        }
    }
}
